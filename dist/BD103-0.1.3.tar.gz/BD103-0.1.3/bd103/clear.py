'''
Clear module for the BD103 Package
'''

import os

def clear():
	os.system("clear")